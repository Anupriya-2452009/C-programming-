#include <stdio.h>
int main(void) {
    double price, gross, discount, taxable, gst, total, net;
    int qty, senior;
    printf("Enter unit price, quantity and senior-citizen status (1=yes, 0=no): ");
    if (scanf("%lf %d %d", &price, &qty, &senior) != 3 || price < 0 || qty < 0 ||
        (senior != 0 && senior != 1)) {
        printf("Invalid input\n");
        return 1;
    }
    gross = price * qty;
    discount = senior ? gross * 0.15 : 0.0;
    taxable = gross - discount;
    gst = taxable * 0.05;
    total = taxable + gst;
    net = total > 1000.0 ? total - 50.0 : total;
    printf("Gross amount: Rs. %.2f\n", gross);
    printf("Senior discount: Rs. %.2f\n", discount);
    printf("GST: Rs. %.2f\n", gst);
    printf("Total before extra discount: Rs. %.2f\n", total);
    printf("Net payable: Rs. %.2f\n", net);
    return 0;
}