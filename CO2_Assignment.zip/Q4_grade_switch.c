#include <stdio.h>
char grade(int marks) {
    if (marks < 0 || marks > 100) return '?';
    switch (marks / 10) {
        case 10:
        case 9: return 'S';
        case 8: return 'A';
        case 7: return 'B';
        case 6: return 'C';
        case 5: return 'D';
        default: return 'F';
    }
}
int main(void) {
    int marks[] = {100, 95, 83, 50, 49, -5, 90, 89, 0, 101};
    for (int i = 0; i < 10; i++)
        printf("%d:%c ", marks[i], grade(marks[i]));
    printf("\n");
    return 0;
}