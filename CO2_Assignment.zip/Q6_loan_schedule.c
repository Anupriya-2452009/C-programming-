#include <stdio.h>
int main(void) {
    double balance, rate, repayment, total_interest = 0.0;
    int month = 0;
    printf("Enter principal, monthly interest rate (%%), fixed repayment: ");
    if (scanf("%lf %lf %lf", &balance, &rate, &repayment) != 3 ||
        balance <= 0 || rate < 0 || repayment <= 0) {
        printf("Invalid input\n");
        return 1;
    }
    if (repayment <= balance * rate / 100.0) {
        printf("Repayment is not greater than the first month's interest; loan will not decrease.\n");
        return 0;
    }
    printf("Month\tOpening\tInterest\tPayment\tClosing\n");
    while (balance > 0.005 && month < 360) {
        double opening = balance;
        double interest = opening * rate / 100.0;
        double due = opening + interest;
        double payment = repayment < due ? repayment : due;
        balance = due - payment;
        total_interest += interest;
        month++;
        printf("%d\t%.2f\t%.2f\t%.2f\t%.2f\n",
               month, opening, interest, payment, balance);
    }
    if (balance <= 0.005)
        printf("Loan repaid in %d months. Total interest: Rs. %.2f\n", month, total_interest);
    else
        printf("Safety limit reached. Remaining balance: Rs. %.2f\n", balance);
    return 0;
}